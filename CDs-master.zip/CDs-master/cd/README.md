# About the CD subversion directory

This directory is split in three big branches:
* [Official](Official): contains all CDs in their form released by the latest
        OpenMath standard.
<!-- * [OfficialDraft](OfficialDraft): contains current work into making the next version
        of the official content-dictionaries for the upcoming OpenMath standard.
-->
* [experimental](experimental): contains all other content dictionaries submitted to us.
  They should be grouped into project or ownerships which should make management easier.
  Each project directory should, if applicable, contain a `cd` and `sts` directory and any
  other applicable file types.
